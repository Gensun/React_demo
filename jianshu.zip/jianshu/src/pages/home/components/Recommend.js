import React, { Component } from 'react'

export class Recommend extends Component {
    render() {
        return <div>Recommend</div>;
    }
}

export default Recommend
