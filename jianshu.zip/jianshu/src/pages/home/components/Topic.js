import React, { PureComponent } from "react";
import { connect } from "react-redux";
import { TopicWrapper, TopicItem } from "../style";

export class Topic extends PureComponent {
  render() {
    const { lists } = this.props;
    console.log(lists);
    return lists && lists.length > 0 ? (
      <TopicWrapper>
        {lists.map((item) => (
          <TopicItem key={item.get("id")}>
            <img className="topic-pic" src={item.get("imgUrl")} alt="" />
            {item.get("title")}
          </TopicItem>
        ))}
      </TopicWrapper>
    ) : (
      "Loading"
    );
  }
}
const mapStateToProps = (state) => {
  console.log("state")
  return {
    lists: state.getIn(["home", "topicList"]),
  };
};

export default connect(mapStateToProps, null)(Topic);
