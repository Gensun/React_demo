import React, { Component } from 'react'

export class Writer extends Component {
    render() {
        return <div>Writer</div>;
    }
}

export default Writer
