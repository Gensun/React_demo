import React, { Component } from 'react'

export class List extends Component {
    render() {
        return <div>List</div>;
    }
}

export default List
