import React, { PureComponent } from "react";
import { connect } from "react-redux";

import { List } from "./components/List";
import { Recommend } from "./components/Recommend";
import { Topic } from "./components/Topic";
import { Writer } from "./components/Writer";

import { actionCreators } from "./store";

import { HomeWrapper, HomeLeft, HomeRight } from "./style";

class Home extends PureComponent {
  render() {
    return (
      <HomeWrapper>
        <HomeLeft>
          <img
            className="banner-img"
            src="https://www.floatingraft.com/img/home-bg.jpg"
            alt=""
          />
          <Topic />
          <List />
        </HomeLeft>
        <HomeRight>
          <Recommend />
          <Writer />
        </HomeRight>
      </HomeWrapper>
    );
  }

  componentDidMount() {
    this.props.changeHomeData();
  }
}

const mapState = (state) => ({});

const mapDispatch = (dispatch) => ({
  changeHomeData() {
    dispatch(actionCreators.getHomeInfo());
  },
});
export default connect(mapState, mapDispatch)(Home);
