import styled from "styled-components";

export const HomeWrapper = styled.div`
  overflow: hidden;
  width: 960px;
  margin: 0 auto;
`;

export const HomeLeft = styled.div`
  width: 625px;
  float: left;
  margin-left: 15px;
  padding-top: 30px;
  height: 100%;
  .banner-img {
    width: 625px;
    height: 270px;
  }
`;

export const TopicWrapper = styled.div`
  overflow: hidden;
  padding: 20px 0 10px 0;
  border-bottom: 1px solid #dcdcdc;
`;
export const TopicItem = styled.div`
  height: 32px;
  background: #f7f7f7;
  color: #000;
  line-height: 32px;
  border-radius: 4px;
  border: 1px solid #dcdcdc;
  font-size: 14px;
  float: left;
  margin-right: 20px;
  padding-right: 10px;
  margin-bottom: 10px;
  .topic-img {
    display: block;
    float: left;
    width: 32px;
    height: 32px;
    margin-right: 10px;
  }
`;

export const TopicItemMore = styled.div`
  height: 32px;
  color: #666;
  line-height: 32px;
  font-size: 12px;
  float: left;
  margin-right: 20px;
  padding-right: 20px;
  margin-bottom: 10px;
`;

export const HomeRight = styled.div`
  width: 240px;
  float: right;
  background: purple;
  height: 100%;
`;
