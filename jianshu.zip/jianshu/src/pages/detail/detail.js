import React, { Component } from 'react'

export class detail extends Component {
    render() {
        return <div>detail</div>;
    }
}

export default detail
