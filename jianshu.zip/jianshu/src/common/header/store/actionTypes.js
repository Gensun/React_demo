export const SEARCH_FOUCED = "header/search-fouced";
export const SEARCH_BLUR = "header/search-blur";
export const CHANGE_LISTS = "header/change-lists";
export const MOUSE_IN = "header/mouse-in";
export const MOUSE_OUT = "header/mouse-out";
export const CHANGEPAGENUMBER = "header/change-number";
